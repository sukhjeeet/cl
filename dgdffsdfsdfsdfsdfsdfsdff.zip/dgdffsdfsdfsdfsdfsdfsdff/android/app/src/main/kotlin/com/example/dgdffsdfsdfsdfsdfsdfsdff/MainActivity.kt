package com.example.dgdffsdfsdfsdfsdfsdfsdff

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
