import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Calculator(),
      debugShowCheckedModeBanner: false, // Remove the debug tag
    );
  }
}

class Calculator extends StatefulWidget {
  @override
  _CalculatorState createState() => _CalculatorState();
}

class _CalculatorState extends State<Calculator> {
  String _output = '0';
  double? _num1;
  double? _num2;
  String? _operator;

  void _buttonPressed(String buttonText) {
    setState(() {
      if (buttonText == 'C') {
        _output = '0';
        _num1 = 0;
        _num2 = 0;
        _operator = null;
      } else if (buttonText == '+' ||
          buttonText == '-' ||
          buttonText == 'x' ||
          buttonText == '/') {
        _num1 = double.parse(_output);
        _operator = buttonText;
        _output = '0';
      } else if (buttonText == '.') {
        if (_output.contains('.')) {
          return;
        } else {
          _output = _output + buttonText;
        }
      } else if (buttonText == '=') {
        _num2 = double.parse(_output);
        if (_operator == '+') {
          _output = (_num1! + _num2!).toString();
        }
        if (_operator == '-') {
          _output = (_num1! - _num2!).toString();
        }
        if (_operator == 'x') {
          _output = (_num1! * _num2!).toString();
        }
        if (_operator == '/') {
          _output = (_num1! / _num2!).toString();
        }

        _num1 = 0;
        _num2 = 0;
        _operator = null;
      } else {
        _output = _output + buttonText;
      }
    });
  }

  Widget _buildButton(String label, {Color? color}) {
    return Expanded(
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: color ?? Colors.grey[200],
        ),
        onPressed: () => _buttonPressed(label),
        child: Text(
          label,
          style: TextStyle(fontSize: 20.0),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: <Widget>[
          Container(
            alignment: Alignment.centerRight,
            padding: EdgeInsets.symmetric(
              vertical: 24.0,
              horizontal: 12.0,
            ),
            child: Text(
              _output,
              style: TextStyle(
                fontSize: 48.0,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            child: Divider(),
          ),
          Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  _buildButton('7'),
                  _buildButton('8'),
                  _buildButton('9'),
                  _buildButton('/', color: Colors.blue),
                ],
              ),
              Row(
                children: <Widget>[
                  _buildButton('4'),
                  _buildButton('5'),
                  _buildButton('6'),
                  _buildButton('x', color: Colors.blue),
                ],
              ),
              Row(
                children: <Widget>[
                  _buildButton('1'),
                  _buildButton('2'),
                  _buildButton('3'),
                  _buildButton('-', color: Colors.blue),
                ],
              ),
              Row(
                children: <Widget>[
                  _buildButton('.'),
                  _buildButton('0'),
                  _buildButton('00'),
                  _buildButton('+', color: Colors.blue),
                ],
              ),
              Row(
                children: <Widget>[
                  _buildButton('C', color: Colors.red),
                  _buildButton('=', color: Colors.green),
                ],
              ),
            ],
          )
        ],
      ),
    );
  }
}
